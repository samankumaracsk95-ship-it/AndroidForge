plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
 namespace = "com.csk.ledcodemaker"
 compileSdk = 35
 defaultConfig { applicationId = "com.csk.ledcodemaker"; minSdk = 23; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
