package com.csk.ledcodemaker

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {
 private var src: Bitmap? = null
 private var mirror = false
 private var saveText = ""
 private lateinit var preview: ImageView
 private lateinit var code: EditText
 private lateinit var size: Spinner
 private lateinit var number: EditText
 private lateinit var mirrorBtn: Button
 private lateinit var status: TextView
 private val pick = 11
 private val save = 12
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); ui() }
 private fun ui() {
  val outer = LinearLayout(this).apply { orientation=1; setPadding(14,12,14,12); setBackgroundColor(Color.rgb(245,247,250)) }
  val scroll=ScrollView(this); val body=LinearLayout(this).apply { orientation=1 }; scroll.addView(body); outer.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
  body.addView(TextView(this).apply { text="CSK LED Code Maker"; textSize=24f; gravity=Gravity.CENTER; setTextColor(Color.rgb(20,45,80)) })
  body.addView(btn("Gallery එකෙන් රූපයක් තෝරන්න") { choose() })
  body.addView(label("Matrix ප්‍රමාණය")); size=Spinner(this); size.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("31 × 16 (අඩක්)","62 × 16 (සම්පූර්ණ)")); body.addView(size); size.onItemSelectedListener=object: android.widget.AdapterView.OnItemSelectedListener { override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {} ; override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position:Int, id:Long) { updatePreview() } }
  body.addView(label("Function අංකය")); number=EditText(this).apply { setText("1"); inputType=InputType.TYPE_CLASS_NUMBER; setSingleLine(true) }; body.addView(number)
  mirrorBtn=btn("වම–දකුණ මාරු කරන්න: OFF") { mirror=!mirror; mirrorBtn.text="වම–දකුණ මාරු කරන්න: "+if(mirror) "ON" else "OFF"; updatePreview() }; body.addView(mirrorBtn)
  preview=ImageView(this).apply { setBackgroundColor(Color.BLACK); adjustViewBounds=true; scaleType=ImageView.ScaleType.FIT_CENTER }; body.addView(preview,LinearLayout.LayoutParams(-1,280))
  status=label("රූපයක් තෝරන්න."); body.addView(status)
  body.addView(btn("Arduino Code හදන්න") { generate() })
  body.addView(btn("Code Copy කරන්න") { (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("Arduino code",code.text)); Toast.makeText(this,"Copied",Toast.LENGTH_SHORT).show() })
  body.addView(btn("TXT ලෙස Save කරන්න") { if(code.text.isNotBlank()){ saveText=code.text.toString(); startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).setType("text/plain").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"csk_led_code.txt"),save) } else Toast.makeText(this,"මුලින් Code හදන්න",Toast.LENGTH_SHORT).show() })
  body.addView(label("Generated Arduino Code")); code=EditText(this).apply { minLines=8; gravity=Gravity.TOP; textSize=12f; typeface=android.graphics.Typeface.MONOSPACE }; body.addView(code,LinearLayout.LayoutParams(-1,260))
  setContentView(outer)
 }
 private fun label(t:String)=TextView(this).apply { text=t; textSize=15f; setTextColor(Color.DKGRAY); setPadding(0,8,0,4) }
 private fun btn(t:String, action:()->Unit)=Button(this).apply { text=t; setOnClickListener { action() } }
 private fun choose(){ startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"),pick) }
 @Deprecated("Legacy result callback") override fun onActivityResult(req:Int,res:Int,data:Intent?){ super.onActivityResult(req,res,data); if(res!=RESULT_OK||data?.data==null)return
  try { if(req==pick){ contentResolver.openInputStream(data.data!!).use { src=BitmapFactory.decodeStream(it) }; mirror=false; mirrorBtn.text="වම–දකුණ මාරු කරන්න: OFF"; updatePreview() } else if(req==save){ contentResolver.openOutputStream(data.data!!).use { it?.write(saveText.toByteArray(Charsets.UTF_8)) }; Toast.makeText(this,"Saved",Toast.LENGTH_SHORT).show() } } catch(e:Exception){ Toast.makeText(this,"ගොනුව විවෘත/Save කළ නොහැක",Toast.LENGTH_LONG).show() }
 }
 private fun width()=if(size.selectedItemPosition==0)31 else 62
 private fun pixelized(b:Bitmap,w:Int):Bitmap = Bitmap.createScaledBitmap(b,w,16,true)
 private fun sample(b:Bitmap,x:Int,y:Int,w:Int):Int { val sx=if(mirror)w-1-x else x; val pixels=pixelizedCache; return pixels.getPixel(sx,y) }
 private var pixelizedCache:Bitmap = Bitmap.createBitmap(1,1,Bitmap.Config.ARGB_8888)
 private var cachedWidth=0
 private fun refreshPixels(){ val b=src?:return; cachedWidth=width(); pixelizedCache=pixelized(b,cachedWidth) }
 private fun updatePreview(){ val b=src?:return; val w=width(); refreshPixels(); val out=Bitmap.createBitmap(w,16,Bitmap.Config.ARGB_8888); for(x in 0 until w)for(y in 0 until 16)out.setPixel(x,y,sample(b,x,y,w)); preview.setImageBitmap(Bitmap.createScaledBitmap(out,w*12,192,false)); status.text="Preview ${w}×16 | මුල් රූපයේ RGB වර්ණ" }
 private fun generate(){ val b=src?:run{Toast.makeText(this,"මුලින් රූපයක් තෝරන්න",Toast.LENGTH_SHORT).show();return}; val w=width(); refreshPixels(); val n=number.text.toString().toIntOrNull()?.coerceAtLeast(1)?:1; val a=Array(w){Array(16){IntArray(3)}}; for(x in 0 until w)for(y in 0 until 16){val c=sample(b,x,y,w);a[x][y][0]=Color.red(c);a[x][y][1]=Color.green(c);a[x][y][2]=Color.blue(c)}
  val dim=if(w==31)"31x16" else "62x16"; val arr=if(w==31)"a31x16" else "a62x16"; val clear=if(w==31)"cleara31x16" else "cleara62x16"; val s=StringBuilder(); s.append("void csk${dim}_${n}() {\n  ${clear}();\n\n"); for(x in 0 until w)for(y in 0 until 16)for(ch in 0..2){val v=a[x][y][ch];if(v!=0)s.append("  ${arr}[$x][$y][$ch] = $v;\n")};s.append("}\n");code.setText(s.toString());number.setText((n+1).toString());status.text="Code ready: csk${dim}_${n}() | RGB වර්ණ සෘජුව ලබාගත්තා" }
}
