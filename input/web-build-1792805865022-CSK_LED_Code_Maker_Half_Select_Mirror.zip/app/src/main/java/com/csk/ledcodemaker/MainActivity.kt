package com.csk.ledcodemaker

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Canvas
import android.graphics.Rect
import android.view.Gravity
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {
 private var src: Bitmap? = null
 private var mirrorHalf = false
 private var saveText = ""
 private lateinit var preview: ImageView
 private lateinit var code: EditText
 private lateinit var side: Spinner
 private lateinit var number: EditText
 private lateinit var mirrorBtn: Button
 private lateinit var status: TextView
 private val pick = 11
 private val save = 12

 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); ui() }

 private fun ui() {
  val outer = LinearLayout(this).apply { orientation=1; setPadding(14,12,14,12); setBackgroundColor(Color.rgb(245,247,250)) }
  val scroll=ScrollView(this)
  val body=LinearLayout(this).apply { orientation=1 }
  scroll.addView(body)
  outer.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
  body.addView(TextView(this).apply { text="CSK LED Code Maker"; textSize=24f; gravity=Gravity.CENTER; setTextColor(Color.rgb(20,45,80)) })
  body.addView(btn("Gallery එකෙන් සම්පූර්ණ රූපය තෝරන්න") { choose() })
  body.addView(label("Code සඳහා ගත යුතු අර්ධය"))
  side=Spinner(this)
  side.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("LEFT HALF (වම් අර්ධය)","RIGHT HALF (දකුණු අර්ධය)"))
  side.onItemSelectedListener=object: android.widget.AdapterView.OnItemSelectedListener {
   override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
   override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) { updatePreview() }
  }
  body.addView(side)
  body.addView(label("Function අංකය"))
  number=EditText(this).apply { setText("1"); inputType=InputType.TYPE_CLASS_NUMBER; setSingleLine(true) }
  body.addView(number)
  mirrorBtn=btn("තෝරාගත් අර්ධය Left ↔ Right: OFF") {
   mirrorHalf=!mirrorHalf
   mirrorBtn.text="තෝරාගත් අර්ධය Left ↔ Right: "+if(mirrorHalf) "ON" else "OFF"
   updatePreview()
  }
  body.addView(mirrorBtn)
  preview=ImageView(this).apply { setBackgroundColor(Color.BLACK); adjustViewBounds=true; scaleType=ImageView.ScaleType.FIT_CENTER }
  body.addView(preview,LinearLayout.LayoutParams(-1,300))
  status=label("රූපයක් තෝරන්න.")
  body.addView(status)
  body.addView(btn("Arduino Code හදන්න") { generate() })
  body.addView(btn("Code Copy කරන්න") {
   (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("Arduino code",code.text))
   Toast.makeText(this,"Copied",Toast.LENGTH_SHORT).show()
  })
  body.addView(btn("TXT ලෙස Save කරන්න") {
   if(code.text.isNotBlank()) { saveText=code.text.toString(); startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).setType("text/plain").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"csk31x16_code.txt"),save) }
   else Toast.makeText(this,"මුලින් Code හදන්න",Toast.LENGTH_SHORT).show()
  })
  body.addView(label("Generated Arduino Code"))
  code=EditText(this).apply { minLines=8; gravity=Gravity.TOP; textSize=12f; typeface=android.graphics.Typeface.MONOSPACE }
  body.addView(code,LinearLayout.LayoutParams(-1,260))
  setContentView(outer)
 }

 private fun label(t:String)=TextView(this).apply { text=t; textSize=15f; setTextColor(Color.DKGRAY); setPadding(0,8,0,4) }
 private fun btn(t:String, action:()->Unit)=Button(this).apply { text=t; setOnClickListener { action() } }
 private fun choose(){ startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"),pick) }

 @Deprecated("Legacy result callback")
 override fun onActivityResult(req:Int,res:Int,data:Intent?) {
  super.onActivityResult(req,res,data)
  if(res!=RESULT_OK||data?.data==null)return
  try {
   if(req==pick) {
    contentResolver.openInputStream(data.data!!).use { src=BitmapFactory.decodeStream(it) }
    mirrorHalf=false
    mirrorBtn.text="තෝරාගත් අර්ධය Left ↔ Right: OFF"
    code.setText("")
    updatePreview()
   } else if(req==save) {
    contentResolver.openOutputStream(data.data!!).use { it?.write(saveText.toByteArray(Charsets.UTF_8)) }
    Toast.makeText(this,"Saved",Toast.LENGTH_SHORT).show()
   }
  } catch(e:Exception) { Toast.makeText(this,"ගොනුව විවෘත/Save කළ නොහැක",Toast.LENGTH_LONG).show() }
 }

 // Select only one half of the original image, then resize that half to 31x16.
 // The mirror switch flips pixels inside the selected half only.
 private fun prepareHalf(): Bitmap? {
  val original=src ?: return null
  val halfWidth=original.width/2
  if(halfWidth<1 || original.height<1) return null
  val left=side.selectedItemPosition==0
  val startX=if(left) 0 else original.width-halfWidth
  val crop=Bitmap.createBitmap(original,startX,0,halfWidth,original.height)
  val scaled=Bitmap.createScaledBitmap(crop,31,16,true)
  if(!mirrorHalf) return scaled
  val flipped=Bitmap.createBitmap(31,16,Bitmap.Config.ARGB_8888)
  for(x in 0 until 31) for(y in 0 until 16) flipped.setPixel(x,y,scaled.getPixel(30-x,y))
  return flipped
 }

 private fun updatePreview() {
  val pixels=prepareHalf() ?: return
  val zoom=20
  val enlarged=Bitmap.createBitmap(31*zoom,16*zoom,Bitmap.Config.ARGB_8888)
  val canvas=Canvas(enlarged)
  val imagePaint=Paint().apply { isFilterBitmap=false }
  canvas.drawBitmap(pixels,null,Rect(0,0,31*zoom,16*zoom),imagePaint)
  val gridPaint=Paint().apply { color=Color.argb(110,0,0,0); strokeWidth=1f }
  for(x in 0..31) canvas.drawLine((x*zoom).toFloat(),0f,(x*zoom).toFloat(),(16*zoom).toFloat(),gridPaint)
  for(y in 0..16) canvas.drawLine(0f,(y*zoom).toFloat(),(31*zoom).toFloat(),(y*zoom).toFloat(),gridPaint)
  preview.setImageBitmap(enlarged)
  status.text=(if(side.selectedItemPosition==0) "LEFT HALF" else "RIGHT HALF")+
   " | Preview 31×16 | "+(if(mirrorHalf) "Mirror ON" else "Mirror OFF")+" | RGB මුල් වර්ණ"
 }

 private fun generate() {
  if(src==null) { Toast.makeText(this,"මුලින් රූපයක් තෝරන්න",Toast.LENGTH_SHORT).show(); return }
  val n=number.text.toString().toIntOrNull()?.coerceAtLeast(1)?:1
  val pixels=prepareHalf() ?: return
  val a=Array(31){Array(16){IntArray(3)}}
  for(x in 0 until 31) for(y in 0 until 16) {
   val c=pixels.getPixel(x,y)
   a[x][y][0]=Color.red(c); a[x][y][1]=Color.green(c); a[x][y][2]=Color.blue(c)
  }
  val s=StringBuilder()
  s.append("void csk31x16_${n}() {\n  cleara31x16();\n\n")
  for(x in 0 until 31) for(y in 0 until 16) for(ch in 0..2) {
   val v=a[x][y][ch]
   if(v!=0) s.append("  a31x16[$x][$y][$ch] = $v;\n")
  }
  s.append("}\n")
  code.setText(s.toString())
  number.setText((n+1).toString())
  status.text="Code ready: csk31x16_${n}() | "+(if(side.selectedItemPosition==0) "LEFT HALF" else "RIGHT HALF")+
   " | Mirror "+(if(mirrorHalf) "ON" else "OFF")
 }
}
